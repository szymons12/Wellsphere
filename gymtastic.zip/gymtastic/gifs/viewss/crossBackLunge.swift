//
//  crossBackLunge.swift
//  Wellsphere
//
//  Created by szymon on 14/02/2022.
//

import SwiftUI

struct crossBackLunge: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct crossBackLunge_Previews: PreviewProvider {
    static var previews: some View {
        crossBackLunge()
    }
}
