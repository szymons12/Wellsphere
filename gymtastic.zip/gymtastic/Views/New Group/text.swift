//
//  text.swift
//  gymtastic
//
//  Created by szymon on 30/11/2021.
//

import SwiftUI

struct text: View {
    var body: some View {
        VStack{
        RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
            .frame(width: 350, height: 100)
            .padding()
        }
        
        
    }
}

struct text_Previews: PreviewProvider {
    static var previews: some View {
        text()
    }
}
