//
//  socialView.swift
//  Wellsphere
//
//  Created by szymon on 11/04/2022.
//

import SwiftUI

struct socialView: View {
    var body: some View {
        ZStack{
            Color("lawenda").ignoresSafeArea()
            VStack{
        Button {
            if let url = URL(string: "https://wellsphere.pl"){
                UIApplication.shared.open(url)
            }
        } label: {
            HStack{
            Image("logoig")
                .resizable()
                .frame(width: 50, height: 50)
                .scaledToFit()
                Text("Strona internetowa")
                    .font(.title2)
                    .foregroundColor(Color.white)
                    
            }
            .padding()
            .background(Color("lawenda2"))
            .cornerRadius(25)
        }
        
        Button {
            if let url = URL(string: "https://www.tiktok.com/@wellsphere"){
                UIApplication.shared.open(url)
            }
        } label: {
            HStack{
            Image("logoig")
                .resizable()
                .frame(width: 50, height: 50)
                .scaledToFit()
                Text("Tik-tok")
                    .font(.title2)
                    .foregroundColor(Color.white)
                    
            }
            .padding()
            .background(Color("lawenda2"))
            .cornerRadius(25)
        }
                
                Button {
                    if let url = URL(string: "https://www.instagram.com/wellsphere_app/?igshid=YmMyMTA2M2Y="){
                        UIApplication.shared.open(url)
                    }
                } label: {
                    HStack{
                    Image("logoig")
                        .resizable()
                        .frame(width: 50, height: 50)
                        .scaledToFit()
                        Text("Instagram")
                            .font(.title2)
                            .foregroundColor(Color.white)
                            
                    }
                    .padding()
                    .background(Color("lawenda2"))
                    .cornerRadius(25)
                }
            }
    }
    }
}

struct socialView_Previews: PreviewProvider {
    static var previews: some View {
        socialView()
    }
}
