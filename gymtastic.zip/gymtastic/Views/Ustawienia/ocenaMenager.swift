//
//  ocenaMenager.swift
//  Wellsphere
//
//  Created by szymon on 04/03/2022.
//

import Foundation

class PersistanceManager{
    enum Keys{
        static let launches = "Launches"
    }
    
    static var shared = PersistanceManager()
    private var defaults = UserDefaults.standard
    
    func fetchLaunches() -> Int {
        return defaults.integer(forKey: Keys.launches)
    }
    
    func schouldRequestReview() -> Bool {
        var launches = fetchLaunches()
        launches += 1
        defaults.set(launches, forKey:  Keys.launches)
        if launches % 3 == 0 {return true}
        return false
    }
}
