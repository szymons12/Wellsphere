//
//  cwiczeniazView.swift
//  Wellsphere
//
//  Created by szymon on 21/02/2022.
//

import SwiftUI

struct cwiczeniazView: View {
    @Environment(\.presentationMode) var presentationMode
    var body: some View {
        Button(action: {
            presentationMode.wrappedValue.dismiss()
        }, label: {
            Image(systemName: "xmark")
                .foregroundColor(Color("lawenda")).font(.title2.weight(.bold))
        })
    }
}

struct cwiczeniazView_Previews: PreviewProvider {
    static var previews: some View {
        cwiczeniazView()
    }
}
