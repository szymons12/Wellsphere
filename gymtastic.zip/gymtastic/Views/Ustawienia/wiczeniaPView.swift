//
//  wiczeniaPView.swift
//  Wellsphere
//
//  Created by szymon on 21/02/2022.
//

import SwiftUI

struct wiczeniaPView: View {
    @Environment(\.presentationMode) var presentationMode
    var body: some View {
        ZStack{
            Color("lawenda2").ignoresSafeArea()
            VStack{
                HStack{
                    Spacer()
                    
            Button(action: {
                presentationMode.wrappedValue.dismiss()
            }, label: {
                Image(systemName: "xmark")
                    .foregroundColor(Color("lawenda")).font(.title2.weight(.bold))
            })
                    Spacer()
                    Spacer()
                    Spacer()
                    Spacer()
                    Spacer()
                    Spacer()
                    Spacer()
                    Spacer()
                }
                Spacer()
                Text("Ćwiczenia podstawowe")
                    .font(.title)
                    .foregroundColor(Color.white)
                    .padding()
                    .background(Color("lawenda"))
                    .cornerRadius(25)
                    .padding()
                    .padding()
                Text("It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).")
                    .font(.subheadline)
                    .foregroundColor(Color.white)
                    .padding()
                    .background(Color("lawenda"))
                    .cornerRadius(25)
                Spacer()
                Spacer()
                Spacer()
                Spacer()
                Spacer()
                Spacer()
            }
            }
        }
    }

struct wiczeniaPView_Previews: PreviewProvider {
    static var previews: some View {
        wiczeniaPView()
    }
}
