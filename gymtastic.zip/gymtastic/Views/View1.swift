//
//  View1.swift
//  gymtastic
//
//  Created by szymon on 29/11/2021.
//

import SwiftUI

struct View1: View {
    init() {
             let navBarAppearance = UINavigationBar.appearance()
             navBarAppearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
             navBarAppearance.titleTextAttributes = [.foregroundColor: UIColor.white]
           }
         
    var body: some View {
        
                NavigationView{
                    ZStack{
                    Color("backgroundColor")
                        .ignoresSafeArea()
                    ScrollView{
                        VStack{
                            //kafelek1
                            
                            NavigationLink(
                                destination: VStack{
                                    Color("backgroundColor")
                                        .ignoresSafeArea()
                                    RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                                        .fill(Color("kafelek"))
                                        .frame(width: 350, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/)
                                        .padding(20)
                                    RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                                        .fill(Color("kafelek"))
                                        .frame(width: 350, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/)
                                        .padding(20)
                                    RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                                        .fill(Color("kafelek"))
                                        .frame(width: 350, height: 350)
                                        .padding(20)
                                }.background(Color("backgroundColor"))
                                .ignoresSafeArea()
                                    ,
                                label: {
                                    RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                                        .fill(Color("kafelek"))
                                        .overlay((Image(systemName: "plus"))
                                        .font(.largeTitle)
                                        .foregroundColor(.white))
                                        .frame(width: 350, height: 180)
                                        .padding(10)
                                })
                            
                            //kafelek2
                            NavigationLink(
                                destination: /*@START_MENU_TOKEN@*/Text("Destination")/*@END_MENU_TOKEN@*/,
                                label: {
                                    RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                                        .fill(Color("kafelek"))
                                        .overlay((Image(systemName: "plus"))
                                        .font(.largeTitle)
                                        .foregroundColor(.white))
                                        .frame(width: 350, height: 180)
                                        .padding(10)
                                })
                            //kafelek3
                            NavigationLink(
                                destination: /*@START_MENU_TOKEN@*/Text("Destination")/*@END_MENU_TOKEN@*/,
                                label: {
                                    RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                                        .fill(Color("kafelek"))
                                        .overlay((Image(systemName: "plus"))
                                        .font(.largeTitle)
                                        .foregroundColor(.white))
                                        .frame(width: 350, height: 180)
                                        .padding(10)
                                })
                            //kafelek4
                            NavigationLink(
                                destination: /*@START_MENU_TOKEN@*/Text("Destination")/*@END_MENU_TOKEN@*/,
                                label: {
                                    RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                                        .fill(Color("kafelek"))
                                        .overlay((Image(systemName: "plus"))
                                        .font(.largeTitle)
                                        .foregroundColor(.white))
                                        .frame(width: 350, height: 180)
                                        .padding(10)
                                })
                            //kafelek5
                            NavigationLink(
                                destination: /*@START_MENU_TOKEN@*/Text("Destination")/*@END_MENU_TOKEN@*/,
                                label: {
                                    RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                                        .fill(Color("kafelek"))
                                        .overlay((Image(systemName: "plus"))
                                        .font(.largeTitle)
                                        .foregroundColor(.white))
                                        .frame(width: 350, height: 180)
                                        .padding(10)
                                })
                                
                        }
                        
                    }
                    }
                    
                    .navigationTitle("Gymtastic")
                    .foregroundColor(.white)
                    .navigationBarTitleDisplayMode(/*@START_MENU_TOKEN@*/.large/*@END_MENU_TOKEN@*/)
                    
                    
                    
                    
                    
                    
                }
            
    }

struct View1_Previews: PreviewProvider {
    static var previews: some View {
        View1()
    }
}
}
