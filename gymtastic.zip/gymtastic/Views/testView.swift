//
//  testView.swift
//  gymtastic
//
//  Created by szymon on 23/12/2021.
//

import SwiftUI

struct testView: App {
    var body: some Scene {
        WindowGroup{
        NavigationView{
            View1Notification()
        }
        }
    }
}


