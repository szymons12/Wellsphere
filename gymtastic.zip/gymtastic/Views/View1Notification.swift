//
//  View1Notification.swift
//  gymtastic
//
//  Created by szymon on 23/12/2021.
//

import SwiftUI

struct View1Notification: View {
   @StateObject private var notificationManager = NotificationManager()
    @State private var isCreatePresented = false
    
    var body: some View {
        NavigationView{
        List(notificationManager.notifications, id: \.identifier) {  notification in
            Text(notification.content.title)
                .fontWeight(.semibold)
        }
        .listStyle(InsetGroupedListStyle())
        .navigationTitle("notifications")
        .onAppear(perform: notificationManager.reloadAuthorizationStatus)
        .onChange(of: notificationManager.authorizationStatus){ authorizationStatus in
            switch authorizationStatus {
            case .notDetermined:
                notificationManager.requestAuthorization()
            break
            case .authorized:
                notificationManager.reloadLocalNotifications()
            default:
                break
            }
        }
        .navigationBarItems(trailing:  Button {
            isCreatePresented = true
        } label:{
            Image(systemName: "plus.circle")
                .imageScale(.large)
        })
        .sheet(isPresented: $isCreatePresented){
            NavigationView{
                CreateNotification(
                    notificationManager: NotificationManager(),
                    isPresented: $isCreatePresented)
            }
        }
        .accentColor(Color("kafelek"))
        }
        
    }
}

struct View1Notification_Previews: PreviewProvider {
    static var previews: some View {
        View1Notification()
    }
}
