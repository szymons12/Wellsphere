/// Copyright (c) 2021 Razeware LLC
///
/// Permission is hereby granted, free of charge, to any person obtaining a copy
/// of this software and associated documentation files (the "Software"), to deal
/// in the Software without restriction, including without limitation the rights
/// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
/// copies of the Software, and to permit persons to whom the Software is
/// furnished to do so, subject to the following conditions:
///
/// The above copyright notice and this permission notice shall be included in
/// all copies or substantial portions of the Software.
///
/// Notwithstanding the foregoing, you may not use, copy, modify, merge, publish,
/// distribute, sublicense, create a derivative work, and/or sell copies of the
/// Software in any work that is designed, intended, or marketed for pedagogical or
/// instructional purposes related to programming, coding, application development,
/// or information technology.  Permission for such use, copying, modification,
/// merger, publication, distribution, sublicensing, creation of derivative works,
/// or sale is expressly withheld.
///
/// This project and source code may use libraries or frameworks that are
/// released under various Open-Source licenses. Use of those libraries and
/// frameworks are governed by their own individual licenses.
///
/// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
/// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
/// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
/// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
/// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
/// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
/// THE SOFTWARE.

import SwiftUI

struct TaskListView: View {
  @ObservedObject var taskManager = TaskManager.shared
  @State var showNotificationSettingsUI = false
    static let newColor = UIColor(red: 0.70, green: 0.66, blue: 0.75, alpha: 1)
    static let newColor2 = Color("B1A8BE")
    init(){
        UITableView.appearance().backgroundColor = TaskListView.newColor
    }
    @State var showCreateTaskView = false
    @ObservedObject var notificationManager = NotificationManager.shared
    @State var showSheet: Bool = false
  var body: some View {
      NavigationView{
    ZStack {
      Color("lawenda").ignoresSafeArea()
      VStack {
          HStack {
              Spacer()
              Spacer()
         Image("bbbaner")
                  .resizable()
                  .frame(width: 290, height: 60)
                  .cornerRadius(25)
                  .clipped()
              Button(action: {
                  showSheet.toggle()
             }, label: {
             Image(systemName: "gearshape.fill")
                     .font(.largeTitle)
                     .foregroundColor(Color("pomarancz"))
              })
                  .fullScreenCover(isPresented: $showSheet, content: {
                      TabelaView()
                  })
              Spacer()
        }
        .padding()
        if taskManager.tasks.isEmpty {
          Spacer()
            Button(
              action: {
                showCreateTaskView = true
                  // 1
                  NotificationManager.shared.requestAuthorization { granted in
                    // 2
                    if granted {
                      showNotificationSettingsUI = true
                    }
                  }
              }, label: {
                  Image("new4")
                         .resizable()
                             .frame(width:380, height: 300)
                             .background(Color(.white))
                             .cornerRadius(25)
                             .clipped()
                             .overlay(Text("zaplanuj trening")
                                         .foregroundColor(Color.white)
                                         .font(.title)
                                         .frame(width: 300, height: 70)
                                         .background(Color("pomarancz").opacity(0.9))
                                         .cornerRadius(25))
              })
                  .background(Color("pomarancz2"))
              .cornerRadius(40)
              .padding()
              .sheet(isPresented: $showCreateTaskView) {
                CreateTaskView()
                  
              }
            Spacer()
          Spacer()
        } else {
            
            List(taskManager.tasks) { task in
              TaskCell(task: task)
                    .listRowBackground(Color("lawenda"))
            }
           
            .cornerRadius(25)
            .padding()
            .onAppear {
                UITableView.appearance().backgroundColor = TaskListView.newColor
            }
            
        }
      }
      AddTaskView()
    }
    .navigationBarHidden(true)
  }

}
}
struct ContentView1_Previews: PreviewProvider {
  static var previews: some View {
    TaskListView()
  }
}

struct TaskCell: View {
  var task: Task
// to tu
  var body: some View {
    HStack{
      Button(
        action: {
          TaskManager.shared.markTaskComplete(task: task)
          DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            TaskManager.shared.remove(task: task)
          }
        }, label: {
          Image(systemName: task.completed ? "checkmark.circle.fill" : "circle")
            .resizable()
            .frame(width: 20, height: 20)
            .accentColor(Color("pomarancz"))
            .foregroundColor(Color("pomarancz"))
        })
      if task.completed {
        Text(task.name)
          .strikethrough()
          .foregroundColor(Color("pomarancz"))
      } else {
        Text(task.name)
              .bold()
          .foregroundColor(Color("lawenda2"))
      }
    }
  }
}

struct AddTaskView: View {
  @State var showCreateTaskView = false

  var body: some View {
    VStack {
      Spacer()
      HStack {
        Spacer()
        Button(
          action: {
            showCreateTaskView = true
          }, label: {
            Text("+")
              .font(.largeTitle)
              .multilineTextAlignment(.center)
              .frame(width: 30, height: 30)
              .foregroundColor(Color.white)
              .padding()
          })
              .background(Color("pomarancz2"))
          .cornerRadius(40)
          .padding()
          .sheet(isPresented: $showCreateTaskView) {
            CreateTaskView()
              
          }
      }
      .padding(.trailing)
    }
      
  }
}
