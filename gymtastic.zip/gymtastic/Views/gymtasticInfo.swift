//
//  gymtasticInfo.swift
//  gymtastic
//
//  Created by szymon on 05/01/2022.
//

import SwiftUI

struct gymtasticInfo: View {
    var body: some View {
        gifImage("pajacyk")
            .frame(width: 200, height: 200)
    }
}

struct gymtasticInfo_Previews: PreviewProvider {
    static var previews: some View {
        gymtasticInfo()
    }
}
