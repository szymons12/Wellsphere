//
//  TabelaView.swift
//  Wellsphere
//
//  Created by szymon on 20/02/2022.
//

import SwiftUI

struct TabelaView: View {
    static let newColor = UIColor(red: 0.70, green: 0.66, blue: 0.75, alpha: 1)
    @Environment(\.presentationMode) var presentationMode
    init(){
        UITableView.appearance().backgroundColor = TabelaView.newColor
    }
    @Environment(\.openURL) var openURL
    var body: some View {
        NavigationView{
            ZStack{
                Color("lawenda2").ignoresSafeArea()
                VStack{
                    HStack{
                        Spacer()
                        Button(action: {
                            presentationMode.wrappedValue.dismiss()
                        }, label: {
                            Image(systemName: "xmark")
                                .foregroundColor(Color("lawenda")).font(.title2.weight(.bold))
                        })
                        Spacer()
                        Spacer()
                    Text("Ustawienia")
                        .foregroundColor(Color.white)
                        .font(.title)
                        .bold()
                        .padding(.trailing)
                        Spacer()
                        Spacer()
                        Spacer()
                    }
                List{
                    NavigationLink(destination: powiadomienia()
                                    , label: {
                        Text("Powiadomienia")
                            .bold()
                            .foregroundColor(Color("pomarancz"))
                    })
                        .listRowBackground(Color("lawenda"))
                    
                    NavigationLink(destination: powiadomienia()
                                    , label: {
                        Text("O nas")
                            .bold()
                            .foregroundColor(Color("pomarancz"))
                    })
                    
                        .listRowBackground(Color("lawenda"))
                    
                    NavigationLink(destination: socialView(), label: {
                        Text("social media")
                            .bold()
                            .foregroundColor(Color("pomarancz"))
                    })
                    
                        .listRowBackground(Color("lawenda"))
                }
                .accentColor(Color("pomarancz"))
                
                    
                }
    }
            .navigationBarHidden(true)
    }
}

struct TabelaView_Previews: PreviewProvider {
    static var previews: some View {
        TabelaView()
    }
}
}
