//
//  SuperTimer.swift
//  gymtastic
//
//  Created by szymon on 27/01/2022.
//

import SwiftUI

struct SuperTimer: View {
    @State var countDownTimer = 5
    @State var timerRuning = false
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
var body: some View {
    VStack{
        Text("\(countDownTimer)")
            .onReceive(timer){ _ in
                if countDownTimer > 0 && timerRuning {
                    countDownTimer -= 1
                } else{
                    timerRuning = false
                }
            }
            .font(.title)
        HStack(spacing: 30){
            Button("start"){
                timerRuning = true
            }
            
            Button("pausa"){
                timerRuning = false
            }
            
            Button("restart"){
                countDownTimer = 5
            }
            Button {
                timerRuning = true
            } label: {
                Image(systemName: "play")
            }
            Button {
                timerRuning = false
            } label: {
                Image(systemName: "pause.circle.fill")
            }
            Button {
                countDownTimer = 60
            } label: {
                Image(systemName: "backward.circle.fill")
            }
        }
    }
        }
    }

struct SuperTimer_Previews: PreviewProvider {
    static var previews: some View {
        SuperTimer()
    }
}
