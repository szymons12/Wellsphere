//
//  ViewOptional.swift
//  gymtastic
//
//  Created by szymon on 05/12/2021.
//

import SwiftUI

struct ViewOptional: View {
    var body: some View {
        
        Text("polska")
            .multilineTextAlignment(.trailing)
        
    }
}

struct ViewOptional_Previews: PreviewProvider {
    static var previews: some View {
        ViewOptional()
    }
}

