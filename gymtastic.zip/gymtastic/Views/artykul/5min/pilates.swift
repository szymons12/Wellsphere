//
//  pilates.swift
//  Wellsphere
//
//  Created by szymon on 07/02/2022.
//

import SwiftUI

struct pilates: View {
    @State var countDownTimer = 90
    @State var countDownTimer2 = 60
    @State var countDownTimer3 = 60
    @State var countDownTimer4 = 90
    @State var countDownTimer5 = 60
    @State var countDownTimer6 = 30
    @State var countDownTimer7 = 30
    @State var countDownTimer8 = 30
    @State var countDownTimer9 = 30
    @State var timerRuning = false
    @State var timerRuning2 = false
    @State var timerRuning3 = false
    @State var timerRuning4 = false
    @State var timerRuning5 = false
    @State var timerRuning6 = false
    @State var timerRuning7 = false
    @State var timerRuning8 = false
    @State var timerRuning9 = false
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    let timer2 = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    let timer3 = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    let timer4 = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    let timer5 = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    let timer6 = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    let timer7 = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    let timer8 = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    let timer9 = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    var body: some View {
        ZStack{
            Color("lawenda2").ignoresSafeArea()
            ScrollView{
            VStack{
                
                RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                    .frame(width: 350, height: 80)
                    .foregroundColor(Color("lawenda"))
                    .overlay(
                    Text("Pilates")
                        .font(.title2)
                        .foregroundColor(Color.white))
                    .padding()
//------------------------------------- Tytul-----------------------------------------
                RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                    .frame(width: 350, height: 220)
                    .foregroundColor(Color("lawenda"))
                    .overlay(
                        VStack{
                            Spacer()
                            Text("opis ćwiczenia")
                                .font(.title2)
                                .foregroundColor(Color.white)
                                .multilineTextAlignment(.center)
                            Spacer()
                            Spacer()
                            
                            Text("Pilates jest uniwersalnym treningiem, który wzmacnia wszystkie partie mięśniowe. Trening ten ma na celu uelastycznienie, rozciągnięcie oraz wzmocnienie mięśni. Trening pomaga również poprawić postawę czy obniżyć poziom stresu.")
                                
                                .font(.subheadline)
                                .foregroundColor(Color.white)
                            
                            Spacer()
                            Spacer()
                            Spacer()
                        }
                    )
//-------------------------------------Opis-------------------------------------------
                ScrollView(.horizontal){
                HStack{
                RoundedRectangle(cornerRadius: 25)
                    .frame(width: 350, height: 520)
                    .foregroundColor(Color("lawenda"))
                    .padding()
                    .overlay(
                        VStack{
                        Text("Kobra")
                                .font(.title2)
                                .foregroundColor(Color.white)
                                .frame(width: 150, height: 70)
                                .background(Color("pomarancz"))
                                .cornerRadius(25)
                            VStack{
                                let minutes = countDownTimer/60
                                let seconds = countDownTimer % 60
                                
                                Text("\(minutes):\(seconds)")
                               // Text("\(countDownTimer)")
                                    .onReceive(timer){ _ in
                                        if countDownTimer > 0 && timerRuning {
                                            countDownTimer -= 1
                                        } else{
                                            timerRuning = false
                                        }
                                    }
                                    .font(.title)
                                    .foregroundColor(Color("pomarancz"))
                                    
                                HStack(spacing: 30){
                                    
                                    Button {
                                        timerRuning = true
                                    } label: {
                                        Image(systemName: "play.circle.fill")
                                            .font(.largeTitle)
                                            .foregroundColor(Color("pomarancz"))
                                    }
                                    
                                    Button {
                                        timerRuning = false
                                    } label: {
                                        Image(systemName: "pause.circle.fill")
                                            .font(.largeTitle)
                                            .foregroundColor(Color("pomarancz"))
                                    }
                                    
                                    Button {
                                        countDownTimer = 90
                                    } label: {
                                        Image(systemName: "gobackward")
                                            .font(.title)
                                            .foregroundColor(Color("pomarancz"))
                                    }
                                }
                                
                                
                            }

                            kobraImage("kobra")
                                .frame(width: 300, height: 300)
                                .cornerRadius(25)
                                .padding()
                            
                            Image(systemName: "arrow.right")
                                    .foregroundColor(Color("lawenda2"))
                        }
                        
                    )
                    
                    RoundedRectangle(cornerRadius: 25)
                        .frame(width: 250, height: 200)
                        .foregroundColor(Color("lawenda"))
                        .padding()
                        .overlay(
                            VStack{
                                Spacer()
                                Spacer()
                                Text("Chwila odpoczynku")
                                    .font(.title2)
                                    .bold()
                                    .foregroundColor(Color("lawenda2"))
                                Spacer()
                                    let minutes = countDownTimer6/60
                                    let seconds = countDownTimer6 % 60
                                    
                                    Text("\(minutes):\(seconds)")
                                        .onReceive(timer6){ _ in
                                            if countDownTimer6 > 0 && timerRuning6 {
                                                countDownTimer6 -= 1
                                            } else{
                                                timerRuning6 = false
                                            }
                                        }
                                        .font(.title)
                                        .foregroundColor(Color.white)
                                        Spacer()
                                    HStack(spacing: 30){
                                        
                                        Button {
                                            timerRuning6 = true
                                        } label: {
                                            Image(systemName: "play.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color.white)
                                        }
                                        
                                        Button {
                                            timerRuning6 = false
                                        } label: {
                                            Image(systemName: "pause.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color.white)
                                        }
                                        
                                        Button {
                                            countDownTimer6 = 30
                                        } label: {
                                            Image(systemName: "gobackward")
                                                .font(.title)
                                                .foregroundColor(Color.white)
                                        }
                                    }
                                Spacer()
                                Spacer()
                                Spacer()
                                    
                                }
                            
                        )
//----------------------------------------------------pierwsze cw--------------------------------------------
                    
                    RoundedRectangle(cornerRadius: 25)
                        .frame(width: 350, height: 520)
                        .foregroundColor(Color("lawenda"))
                        .padding()
                        .overlay(
                            VStack{
                            Text("Flutterkicks")
                                    .font(.title2)
                                    .foregroundColor(Color.white)
                                    .frame(width: 150, height: 70)
                                    .background(Color("pomarancz"))
                                    .cornerRadius(25)
                                VStack{
                                    let minutes = countDownTimer2/60
                                    let seconds = countDownTimer2 % 60
                                    
                                    Text("\(minutes):\(seconds)")
                                   // Text("\(countDownTimer2)")
                                        .onReceive(timer2){ _ in
                                            if countDownTimer2 > 0 && timerRuning2 {
                                                countDownTimer2 -= 1
                                            } else{
                                                timerRuning2 = false
                                            }
                                        }
                                        .font(.title)
                                        .foregroundColor(Color("pomarancz"))
                                        
                                    HStack(spacing: 30){
                                        
                                        Button {
                                            timerRuning2 = true
                                        } label: {
                                            Image(systemName: "play.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                        
                                        Button {
                                            timerRuning2 = false
                                        } label: {
                                            Image(systemName: "pause.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                        
                                        Button {
                                            countDownTimer2 = 60
                                        } label: {
                                            Image(systemName: "gobackward")
                                                .font(.title)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                    }
                                    
                                    
                                }
    //---------------------------------------gif-------------------------------------------------------------
                                flutterkicksImage("flutterkicks")
                                    .frame(width: 300, height: 300)
                                    .cornerRadius(25)
                                    .padding()
                                
                                Image(systemName: "arrow.right")
                                        .foregroundColor(Color("lawenda2"))
                }
                )
                    
                    RoundedRectangle(cornerRadius: 25)
                        .frame(width: 250, height: 200)
                        .foregroundColor(Color("lawenda"))
                        .padding()
                        .overlay(
                            VStack{
                                Spacer()
                                Spacer()
                                Text("Chwila odpoczynku")
                                    .font(.title2)
                                    .bold()
                                    .foregroundColor(Color("lawenda2"))
                                Spacer()
                                    let minutes = countDownTimer7/60
                                    let seconds = countDownTimer7 % 60
                                    
                                    Text("\(minutes):\(seconds)")
                                        .onReceive(timer7){ _ in
                                            if countDownTimer7 > 0 && timerRuning7 {
                                                countDownTimer7 -= 1
                                            } else{
                                                timerRuning7 = false
                                            }
                                        }
                                        .font(.title)
                                        .foregroundColor(Color.white)
                                        Spacer()
                                    HStack(spacing: 30){
                                        
                                        Button {
                                            timerRuning7 = true
                                        } label: {
                                            Image(systemName: "play.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color.white)
                                        }
                                        
                                        Button {
                                            timerRuning7 = false
                                        } label: {
                                            Image(systemName: "pause.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color.white)
                                        }
                                        
                                        Button {
                                            countDownTimer7 = 30
                                        } label: {
                                            Image(systemName: "gobackward")
                                                .font(.title)
                                                .foregroundColor(Color.white)
                                        }
                                    }
                                Spacer()
                                Spacer()
                                Spacer()
                                    
                                }
                            
                        )
//-------------------------------------------------cw 3----------------------------------------------
                    RoundedRectangle(cornerRadius: 25)
                        .frame(width: 350, height: 520)
                        .foregroundColor(Color("lawenda"))
                        .padding()
                        .overlay(
                            VStack{
                            Text("Gąsienica")
                                    .font(.title2)
                                    .foregroundColor(Color.white)
                                    .frame(width: 150, height: 70)
                                    .background(Color("pomarancz"))
                                    .cornerRadius(25)
                                VStack{
                                    let minutes = countDownTimer3/60
                                    let seconds = countDownTimer3 % 60
                                    
                                    Text("\(minutes):\(seconds)")
                                  //  Text("\(countDownTimer3)")
                                        .onReceive(timer3){ _ in
                                            if countDownTimer3 > 0 && timerRuning3 {
                                                countDownTimer3 -= 1
                                            } else{
                                                timerRuning3 = false
                                            }
                                        }
                                        .font(.title)
                                        .foregroundColor(Color("pomarancz"))
                                        
                                    HStack(spacing: 30){
                                        
                                        Button {
                                            timerRuning3 = true
                                        } label: {
                                            Image(systemName: "play.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                        
                                        Button {
                                            timerRuning3 = false
                                        } label: {
                                            Image(systemName: "pause.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                        
                                        Button {
                                            countDownTimer3 = 60
                                        } label: {
                                            Image(systemName: "gobackward")
                                                .font(.title)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                    }
                                    
                                    
                                }

                                gasienicaImage("gasienica")
                                    .frame(width: 300, height: 300)
                                    .cornerRadius(25)
                                    .padding()
                                
                                Image(systemName: "arrow.right")
                                        .foregroundColor(Color("lawenda2"))
                            }
                            
                        )
                    
                    RoundedRectangle(cornerRadius: 25)
                        .frame(width: 250, height: 200)
                        .foregroundColor(Color("lawenda"))
                        .padding()
                        .overlay(
                            VStack{
                                Spacer()
                                Spacer()
                                Text("Chwila odpoczynku")
                                    .font(.title2)
                                    .bold()
                                    .foregroundColor(Color("lawenda2"))
                                Spacer()
                                    let minutes = countDownTimer8/60
                                    let seconds = countDownTimer8 % 60
                                    
                                    Text("\(minutes):\(seconds)")
                                        .onReceive(timer6){ _ in
                                            if countDownTimer8 > 0 && timerRuning8 {
                                                countDownTimer8 -= 1
                                            } else{
                                                timerRuning8 = false
                                            }
                                        }
                                        .font(.title)
                                        .foregroundColor(Color.white)
                                        Spacer()
                                    HStack(spacing: 30){
                                        
                                        Button {
                                            timerRuning8 = true
                                        } label: {
                                            Image(systemName: "play.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color.white)
                                        }
                                        
                                        Button {
                                            timerRuning8 = false
                                        } label: {
                                            Image(systemName: "pause.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color.white)
                                        }
                                        
                                        Button {
                                            countDownTimer8 = 30
                                        } label: {
                                            Image(systemName: "gobackward")
                                                .font(.title)
                                                .foregroundColor(Color.white)
                                        }
                                    }
                                Spacer()
                                Spacer()
                                Spacer()
                                    
                                }
                            
                        )
//--------------------------------------------------cw 4---------------------------------------------
                    RoundedRectangle(cornerRadius: 25)
                        .frame(width: 350, height: 520)
                        .foregroundColor(Color("lawenda"))
                        .padding()
                        .overlay(
                            VStack{
                            Text("Wykroki")
                                    .font(.title2)
                                    .foregroundColor(Color.white)
                                    .frame(width: 150, height: 70)
                                    .background(Color("pomarancz"))
                                    .cornerRadius(25)
                                VStack{
                                    let minutes = countDownTimer4/60
                                    let seconds = countDownTimer4 % 60
                                    
                                    Text("\(minutes):\(seconds)")
                                  //  Text("\(countDownTimer4)")
                                        .onReceive(timer4){ _ in
                                            if countDownTimer4 > 0 && timerRuning4 {
                                                countDownTimer4 -= 1
                                            } else{
                                                timerRuning4 = false
                                            }
                                        }
                                        .font(.title)
                                        .foregroundColor(Color("pomarancz"))
                                        
                                    HStack(spacing: 30){
                                        
                                        Button {
                                            timerRuning4 = true
                                        } label: {
                                            Image(systemName: "play.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                        
                                        Button {
                                            timerRuning4 = false
                                        } label: {
                                            Image(systemName: "pause.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                        
                                        Button {
                                            countDownTimer4 = 90
                                        } label: {
                                            Image(systemName: "gobackward")
                                                .font(.title)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                    }
                                    
                                    
                                }

                                wykrokImage("wykroki")
                                    .frame(width: 300, height: 300)
                                    .cornerRadius(25)
                                    .padding()
                                
                                Image(systemName: "arrow.right")
                                        .foregroundColor(Color("lawenda2"))
                            }
                            
                        )
                    
                    RoundedRectangle(cornerRadius: 25)
                        .frame(width: 250, height: 200)
                        .foregroundColor(Color("lawenda"))
                        .padding()
                        .overlay(
                            VStack{
                                Spacer()
                                Spacer()
                                Text("Chwila odpoczynku")
                                    .font(.title2)
                                    .bold()
                                    .foregroundColor(Color("lawenda2"))
                                Spacer()
                                    let minutes = countDownTimer9/60
                                    let seconds = countDownTimer9 % 60
                                    
                                    Text("\(minutes):\(seconds)")
                                        .onReceive(timer9){ _ in
                                            if countDownTimer9 > 0 && timerRuning9 {
                                                countDownTimer9 -= 1
                                            } else{
                                                timerRuning9 = false
                                            }
                                        }
                                        .font(.title)
                                        .foregroundColor(Color.white)
                                        Spacer()
                                    HStack(spacing: 30){
                                        
                                        Button {
                                            timerRuning9 = true
                                        } label: {
                                            Image(systemName: "play.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color.white)
                                        }
                                        
                                        Button {
                                            timerRuning9 = false
                                        } label: {
                                            Image(systemName: "pause.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color.white)
                                        }
                                        
                                        Button {
                                            countDownTimer6 = 30
                                        } label: {
                                            Image(systemName: "gobackward")
                                                .font(.title)
                                                .foregroundColor(Color.white)
                                        }
                                    }
                                Spacer()
                                Spacer()
                                Spacer()
                                    
                                }
                            
                        )
//---------------------------------------------gratulacje--------------------------------------------
                    RoundedRectangle(cornerRadius: 25)
                        .frame(width: 350, height: 520)
                        .foregroundColor(Color("lawenda"))
                        .padding()
                        .overlay(
                            VStack{
                            Text("T plank")
                                    .font(.title2)
                                    .foregroundColor(Color.white)
                                    .frame(width: 150, height: 70)
                                    .background(Color("pomarancz"))
                                    .cornerRadius(25)
                                VStack{
                                    let minutes = countDownTimer5/60
                                    let seconds = countDownTimer5 % 60
                                    
                                    Text("\(minutes):\(seconds)")
                                  //  Text("\(countDownTimer5)")
                                        .onReceive(timer5){ _ in
                                            if countDownTimer5 > 0 && timerRuning5 {
                                                countDownTimer5 -= 1
                                            } else{
                                                timerRuning5 = false
                                            }
                                        }
                                        .font(.title)
                                        .foregroundColor(Color("pomarancz"))
                                        
                                    HStack(spacing: 30){
                                        
                                        Button {
                                            timerRuning5 = true
                                        } label: {
                                            Image(systemName: "play.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                        
                                        Button {
                                            timerRuning5 = false
                                        } label: {
                                            Image(systemName: "pause.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                        
                                        Button {
                                            countDownTimer5 = 60
                                        } label: {
                                            Image(systemName: "gobackward")
                                                .font(.title)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                    }
                                    
                                    
                                }

                                sideplankImage("sideplank")
                                    .frame(width: 300, height: 300)
                                    .cornerRadius(25)
                                    .padding()
                                
                                Image(systemName: "arrow.right")
                                        .foregroundColor(Color("lawenda2"))
                            }
                            
                        )
                    
                    RoundedRectangle(cornerRadius: 25)
                        .frame(width: 350, height: 520)
                        .foregroundColor(Color("lawenda"))
                        .padding()
                        .overlay(
                            VStack{
                                Spacer()
                                Text("Gratulacje")
                                    .font(.title)
                                    .foregroundColor(Color.white)
                                    .padding()
                                    .background(Color("pomarancz"))
                                    .cornerRadius(25)
                                Spacer()
                        superImage("super")
                            .frame(width: 300, height: 300)
                            .cornerRadius(25)
                                Spacer()
                            }
                        )
                }
//-------------------------------------Cwiczenia--------------------------------------
                }
            }
            
        }
        
    }
}

struct pilates_Previews: PreviewProvider {
    static var previews: some View {
        pilates()
    }
}
}
