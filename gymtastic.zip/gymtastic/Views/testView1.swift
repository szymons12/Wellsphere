//
//  testView1.swift
//  Wellsphere
//
//  Created by szymon on 07/02/2022.
//

import SwiftUI

struct testView1: View {
    var body: some View {
        ZStack{
            Color("lawenda").ignoresSafeArea()
            VStack{
                Image("bbbaner")
                    .resizable()
                    .frame(width: 460, height: 100)
                    .clipped()
            }
        }
    }
}

struct testView1_Previews: PreviewProvider {
    static var previews: some View {
        testView1()
    }
}
