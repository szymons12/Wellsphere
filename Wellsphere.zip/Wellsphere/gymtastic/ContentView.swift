//
//  ContentView.swift
//  gymtastic
//
//  Created by szymon on 18/11/2021.
//

import SwiftUI

struct ContentView: View {
    static let newColor4 = UIColor(red: 0.34, green: 0.34, blue: 0.34, alpha: 1.00)
    var body: some View {
        TabView{
            TaskListView()
                .tabItem{
                    Image(systemName: "leaf.fill")
                }
                .tag(1)
            
            View33()
                .tabItem{
                    Image(systemName: "flame.fill")
                }
                .tag(2)
        }
        .onAppear() {
            UITabBar.appearance().backgroundColor = .white
                }
       .accentColor(Color("pomarancz"))

}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .preferredColorScheme(.light)
    }
}




}
