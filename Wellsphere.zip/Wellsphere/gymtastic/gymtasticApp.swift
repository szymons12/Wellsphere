//
//  gymtasticApp.swift
//  gymtastic
//
//  Created by szymon on 18/11/2021.
//

import SwiftUI
@main
struct gymtasticApp: App {
    var body: some Scene {
        WindowGroup{
            ContentView()
        }
        }
    }

