//
//  Cardio.swift
//  Wellsphere
//
//  Created by szymon on 13/02/2022.
//

import SwiftUI
struct Cardio: View {
    @State var countDownTimer = 60
    @State var countDownTimer2 = 90
    @State var countDownTimer3 = 90
    @State var countDownTimer4 = 60
    @State var countDownTimer5 = 90
    @State var countDownTimer6 = 90
    @State var countDownTimer7 = 120
    @State var countDownTimer8 = 30
    @State var countDownTimer9 = 30
    @State var countDownTimer10 = 30
    @State var countDownTimer14 = 30
    @State var countDownTimer12 = 30
    @State var countDownTimer13 = 30
    @State var timerRuning = false
    @State var timerRuning2 = false
    @State var timerRuning3 = false
    @State var timerRuning4 = false
    @State var timerRuning5 = false
    @State var timerRuning6 = false
    @State var timerRuning7 = false
    @State var timerRuning8 = false
    @State var timerRuning9 = false
    @State var timerRuning10 = false
    @State var timerRuning14 = false
    @State var timerRuning12 = false
    @State var timerRuning13 = false
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    let timer2 = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    let timer3 = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    let timer4 = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    let timer5 = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    let timer6 = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    let timer7 = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    let timer8 = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    let timer9 = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    let timer10 = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    let timer14 = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    let timer12 = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    let timer13 = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    var body: some View {
        ZStack{
            Color("lawenda2").ignoresSafeArea()
            ScrollView{
            VStack{
                RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                    .frame(width: 350, height: 80)
                    .foregroundColor(Color("lawenda"))
                    .overlay(
                    Text("Trening cardio")
                        .font(.title2)
                        .foregroundColor(Color.white))
                    .padding()
//------------------------------------- Tytul-----------------------------------------
                RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                    .frame(width: 350, height: 220)
                    .foregroundColor(Color("lawenda"))
                    .overlay(
                        VStack{
                            Spacer()
                            Text("opis ćwiczenia")
                                .font(.title2)
                                .foregroundColor(Color.white)
                                .multilineTextAlignment(.center)
                            Spacer()
                            Spacer()
                            
                            Text(" Cardio to trening wytrzymałościowy, podczas którego znacząco wzrasta tętno oraz ilość oddechów na minutę. Trening ten pozytywnie wpływa na pracę układu krążenia i przyspiesza spalanie tkanki tłuszczowej")
                                .font(.subheadline)
                                .foregroundColor(Color.white)
                            
                            Spacer()
                            Spacer()
                            Spacer()
                        }
                    )
//-------------------------------------Opis-------------------------------------------
                ScrollView(.horizontal){
                HStack{
                RoundedRectangle(cornerRadius: 25)
                    .frame(width: 350, height: 520)
                    .foregroundColor(Color("lawenda"))
                    .padding()
                    .overlay(
                        VStack{
                        Text("Pompki")
                                .font(.title2)
                                .foregroundColor(Color.white)
                                .frame(width: 150, height: 70)
                                .background(Color("pomarancz"))
                                .cornerRadius(25)
                            VStack{
                                let minutes = countDownTimer/60
                                let seconds = countDownTimer % 60
                                
                                Text("\(minutes):\(seconds)")
                               // Text("\(countDownTimer)")
                                    .onReceive(timer){ _ in
                                        if countDownTimer > 0 && timerRuning {
                                            countDownTimer -= 1
                                        } else{
                                            timerRuning = false
                                        }
                                    }
                                    .font(.title)
                                    .foregroundColor(Color("pomarancz"))
                                    
                                HStack(spacing: 30){
                                    
                                    Button {
                                        timerRuning = true
                                    } label: {
                                        Image(systemName: "play.circle.fill")
                                            .font(.largeTitle)
                                            .foregroundColor(Color("pomarancz"))
                                    }
                                    
                                    Button {
                                        timerRuning = false
                                    } label: {
                                        Image(systemName: "pause.circle.fill")
                                            .font(.largeTitle)
                                            .foregroundColor(Color("pomarancz"))
                                    }
                                    
                                    Button {
                                        countDownTimer = 60
                                    } label: {
                                        Image(systemName: "gobackward")
                                            .font(.title)
                                            .foregroundColor(Color("pomarancz"))
                                    }
                                }
                                
                                
                            }

                            pompkaImage("pompki")
                                .frame(width: 300, height: 300)
                                .cornerRadius(25)
                                .padding()
                            
                            Image(systemName: "arrow.right")
                                    .foregroundColor(Color("lawenda2"))
                        }
                        
                    )
                    
                    RoundedRectangle(cornerRadius: 25)
                        .frame(width: 250, height: 200)
                        .foregroundColor(Color("lawenda"))
                        .padding()
                        .overlay(
                            VStack{
                                Spacer()
                                Spacer()
                                Text("Chwila odpoczynku")
                                    .font(.title2)
                                    .bold()
                                    .foregroundColor(Color("lawenda2"))
                                Spacer()
                                    let minutes = countDownTimer8/60
                                    let seconds = countDownTimer8 % 60
                                    
                                    Text("\(minutes):\(seconds)")
                                        .onReceive(timer8){ _ in
                                            if countDownTimer8 > 0 && timerRuning8 {
                                                countDownTimer8 -= 1
                                            } else{
                                                timerRuning8 = false
                                            }
                                        }
                                        .font(.title)
                                        .foregroundColor(Color.white)
                                        Spacer()
                                    HStack(spacing: 30){
                                        
                                        Button {
                                            timerRuning8 = true
                                        } label: {
                                            Image(systemName: "play.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color.white)
                                        }
                                        
                                        Button {
                                            timerRuning8 = false
                                        } label: {
                                            Image(systemName: "pause.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color.white)
                                        }
                                        
                                        Button {
                                            countDownTimer8 = 30
                                        } label: {
                                            Image(systemName: "gobackward")
                                                .font(.title)
                                                .foregroundColor(Color.white)
                                        }
                                    }
                                Spacer()
                                Spacer()
                                Spacer()
                                    
                                }
                            
                        )
//----------------------------------------------------pierwsze cw--------------------------------------------
                    
                    RoundedRectangle(cornerRadius: 25)
                        .frame(width: 350, height: 520)
                        .foregroundColor(Color("lawenda"))
                        .padding()
                        .overlay(
                            VStack{
                            Text("Deska")
                                    .font(.title2)
                                    .foregroundColor(Color.white)
                                    .frame(width: 150, height: 70)
                                    .background(Color("pomarancz"))
                                    .cornerRadius(25)
                                VStack{
                                    let minutes = countDownTimer2/60
                                    let seconds = countDownTimer2 % 60
                                    
                                    Text("\(minutes):\(seconds)")
                                   // Text("\(countDownTimer2)")
                                        .onReceive(timer2){ _ in
                                            if countDownTimer2 > 0 && timerRuning2 {
                                                countDownTimer2 -= 1
                                            } else{
                                                timerRuning2 = false
                                            }
                                        }
                                        .font(.title)
                                        .foregroundColor(Color("pomarancz"))
                                        
                                    HStack(spacing: 30){
                                        
                                        Button {
                                            timerRuning2 = true
                                        } label: {
                                            Image(systemName: "play.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                        
                                        Button {
                                            timerRuning2 = false
                                        } label: {
                                            Image(systemName: "pause.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                        
                                        Button {
                                            countDownTimer2 = 90
                                        } label: {
                                            Image(systemName: "gobackward")
                                                .font(.title)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                    }
                                    
                                    
                                }
    //---------------------------------------gif-------------------------------------------------------------
                                deskaImage("deska")
                                    .frame(width: 300, height: 300)
                                    .cornerRadius(25)
                                    .padding()
                                
                                Image(systemName: "arrow.right")
                                        .foregroundColor(Color("lawenda2"))
                }
                )
                    
                    RoundedRectangle(cornerRadius: 25)
                        .frame(width: 250, height: 200)
                        .foregroundColor(Color("lawenda"))
                        .padding()
                        .overlay(
                            VStack{
                                Spacer()
                                Spacer()
                                Text("Chwila odpoczynku")
                                    .font(.title2)
                                    .bold()
                                    .foregroundColor(Color("lawenda2"))
                                Spacer()
                                    let minutes = countDownTimer9/60
                                    let seconds = countDownTimer9 % 60
                                    
                                    Text("\(minutes):\(seconds)")
                                        .onReceive(timer9){ _ in
                                            if countDownTimer9 > 0 && timerRuning9 {
                                                countDownTimer9 -= 1
                                            } else{
                                                timerRuning9 = false
                                            }
                                        }
                                        .font(.title)
                                        .foregroundColor(Color.white)
                                        Spacer()
                                    HStack(spacing: 30){
                                        
                                        Button {
                                            timerRuning9 = true
                                        } label: {
                                            Image(systemName: "play.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color.white)
                                        }
                                        
                                        Button {
                                            timerRuning9 = false
                                        } label: {
                                            Image(systemName: "pause.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color.white)
                                        }
                                        
                                        Button {
                                            countDownTimer9 = 30
                                        } label: {
                                            Image(systemName: "gobackward")
                                                .font(.title)
                                                .foregroundColor(Color.white)
                                        }
                                    }
                                Spacer()
                                Spacer()
                                Spacer()
                                    
                                }
                            
                        )
//-------------------------------------------------cw 3----------------------------------------------
                    RoundedRectangle(cornerRadius: 25)
                        .frame(width: 350, height: 520)
                        .foregroundColor(Color("lawenda"))
                        .padding()
                        .overlay(
                            VStack{
                            Text("Przysiady z wyskokiem")
                                    .font(.title2)
                                    .multilineTextAlignment(.center)
                                    .foregroundColor(Color.white)
                                    .frame(width: 150, height: 70)
                                    .background(Color("pomarancz"))
                                    .cornerRadius(25)
                                VStack{
                                    let minutes = countDownTimer3/60
                                    let seconds = countDownTimer3 % 60
                                    
                                    Text("\(minutes):\(seconds)")
                                  //  Text("\(countDownTimer3)")
                                        .onReceive(timer3){ _ in
                                            if countDownTimer3 > 0 && timerRuning3 {
                                                countDownTimer3 -= 1
                                            } else{
                                                timerRuning3 = false
                                            }
                                        }
                                        .font(.title)
                                        .foregroundColor(Color("pomarancz"))
                                        
                                    HStack(spacing: 30){
                                        
                                        Button {
                                            timerRuning3 = true
                                        } label: {
                                            Image(systemName: "play.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                        
                                        Button {
                                            timerRuning3 = false
                                        } label: {
                                            Image(systemName: "pause.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                        
                                        Button {
                                            countDownTimer3 = 90
                                        } label: {
                                            Image(systemName: "gobackward")
                                                .font(.title)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                    }
                                    
                                    
                                }

                                gifImage2("skok")
                                    .frame(width: 300, height: 300)
                                    .cornerRadius(25)
                                    .padding()
                                
                                Image(systemName: "arrow.right")
                                        .foregroundColor(Color("lawenda2"))
                            }
                            
                        )
                 
                    RoundedRectangle(cornerRadius: 25)
                        .frame(width: 250, height: 200)
                        .foregroundColor(Color("lawenda"))
                        .padding()
                        .overlay(
                            VStack{
                                Spacer()
                                Spacer()
                                Text("Chwila odpoczynku")
                                    .font(.title2)
                                    .bold()
                                    .foregroundColor(Color("lawenda2"))
                                Spacer()
                                    let minutes = countDownTimer10/60
                                    let seconds = countDownTimer10 % 60
                                    
                                    Text("\(minutes):\(seconds)")
                                        .onReceive(timer10){ _ in
                                            if countDownTimer10 > 0 && timerRuning10 {
                                                countDownTimer10 -= 1
                                            } else{
                                                timerRuning10 = false
                                            }
                                        }
                                        .font(.title)
                                        .foregroundColor(Color.white)
                                        Spacer()
                                    HStack(spacing: 30){
                                        
                                        Button {
                                            timerRuning10 = true
                                        } label: {
                                            Image(systemName: "play.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color.white)
                                        }
                                        
                                        Button {
                                            timerRuning10 = false
                                        } label: {
                                            Image(systemName: "pause.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color.white)
                                        }
                                        
                                        Button {
                                            countDownTimer10 = 30
                                        } label: {
                                            Image(systemName: "gobackward")
                                                .font(.title)
                                                .foregroundColor(Color.white)
                                        }
                                    }
                                Spacer()
                                Spacer()
                                Spacer()
                                    
                                }
                            
                        )
                    
//--------------------------------------------------cw 4---------------------------------------------
                    RoundedRectangle(cornerRadius: 25)
                        .frame(width: 350, height: 520)
                        .foregroundColor(Color("lawenda"))
                        .padding()
                        .overlay(
                            VStack{
                            Text("Cross back lunge")
                                    .font(.title2)
                                    .multilineTextAlignment(.center)
                                    .foregroundColor(Color.white)
                                    .frame(width: 150, height: 70)
                                    .background(Color("pomarancz"))
                                    .cornerRadius(25)
                                VStack{
                                    let minutes = countDownTimer4/60
                                    let seconds = countDownTimer4 % 60
                                    
                                    Text("\(minutes):\(seconds)")
                                  //  Text("\(countDownTimer4)")
                                        .onReceive(timer4){ _ in
                                            if countDownTimer4 > 0 && timerRuning4 {
                                                countDownTimer4 -= 1
                                            } else{
                                                timerRuning4 = false
                                            }
                                        }
                                        .font(.title)
                                        .foregroundColor(Color("pomarancz"))
                                        
                                    HStack(spacing: 30){
                                        
                                        Button {
                                            timerRuning4 = true
                                        } label: {
                                            Image(systemName: "play.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                        
                                        Button {
                                            timerRuning4 = false
                                        } label: {
                                            Image(systemName: "pause.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                        
                                        Button {
                                            countDownTimer4 = 60
                                        } label: {
                                            Image(systemName: "gobackward")
                                                .font(.title)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                    }
                                    
                                    
                                }

                                crossBackLungeImage("crossbackLunge")
                                    .frame(width: 300, height: 300)
                                    .cornerRadius(25)
                                    .padding()
                                
                                Image(systemName: "arrow.right")
                                        .foregroundColor(Color("lawenda2"))
                            }
                            
                        )
                    
                    RoundedRectangle(cornerRadius: 25)
                        .frame(width: 250, height: 200)
                        .foregroundColor(Color("lawenda"))
                        .padding()
                        .overlay(
                            VStack{
                                Spacer()
                                Spacer()
                                Text("Chwila odpoczynku")
                                    .font(.title2)
                                    .bold()
                                    .foregroundColor(Color("lawenda2"))
                                Spacer()
                                    let minutes = countDownTimer14/60
                                    let seconds = countDownTimer14 % 60
                                    
                                    Text("\(minutes):\(seconds)")
                                        .onReceive(timer14){ _ in
                                            if countDownTimer14 > 0 && timerRuning14 {
                                                countDownTimer14 -= 1
                                            } else{
                                                timerRuning14 = false
                                            }
                                        }
                                        .font(.title)
                                        .foregroundColor(Color.white)
                                        Spacer()
                                    HStack(spacing: 30){
                                        
                                        Button {
                                            timerRuning14 = true
                                        } label: {
                                            Image(systemName: "play.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color.white)
                                        }
                                        
                                        Button {
                                            timerRuning14 = false
                                        } label: {
                                            Image(systemName: "pause.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color.white)
                                        }
                                        
                                        Button {
                                            countDownTimer14 = 30
                                        } label: {
                                            Image(systemName: "gobackward")
                                                .font(.title)
                                                .foregroundColor(Color.white)
                                        }
                                    }
                                Spacer()
                                Spacer()
                                Spacer()
                                    
                                }
                            
                        )
                    Group{
                    RoundedRectangle(cornerRadius: 25)
                        .frame(width: 350, height: 520)
                        .foregroundColor(Color("lawenda"))
                        .padding()
                        .overlay(
                            VStack{
                            Text("Skip A")
                                    .font(.title2)
                                    .foregroundColor(Color.white)
                                    .frame(width: 150, height: 70)
                                    .background(Color("pomarancz"))
                                    .cornerRadius(25)
                                VStack{
                                    let minutes = countDownTimer5/60
                                    let seconds = countDownTimer5 % 60
                                    
                                    Text("\(minutes):\(seconds)")
                                  //  Text("\(countDownTimer5)")
                                        .onReceive(timer5){ _ in
                                            if countDownTimer5 > 0 && timerRuning5 {
                                                countDownTimer5 -= 1
                                            } else{
                                                timerRuning5 = false
                                            }
                                        }
                                        .font(.title)
                                        .foregroundColor(Color("pomarancz"))
                                        
                                    HStack(spacing: 30){
                                        
                                        Button {
                                            timerRuning5 = true
                                        } label: {
                                            Image(systemName: "play.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                        
                                        Button {
                                            timerRuning5 = false
                                        } label: {
                                            Image(systemName: "pause.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                        
                                        Button {
                                            countDownTimer5 = 90
                                        } label: {
                                            Image(systemName: "gobackward")
                                                .font(.title)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                    }
                                    
                                    
                                }

                                skipaImage("skipaa")
                                    .frame(width: 300, height: 300)
                                    .cornerRadius(25)
                                    .padding()
                                
                                Image(systemName: "arrow.right")
                                        .foregroundColor(Color("lawenda2"))
                            }
                            
                        )
                    
                        RoundedRectangle(cornerRadius: 25)
                            .frame(width: 250, height: 200)
                            .foregroundColor(Color("lawenda"))
                            .padding()
                            .overlay(
                                VStack{
                                    Spacer()
                                    Spacer()
                                    Text("Chwila odpoczynku")
                                        .font(.title2)
                                        .bold()
                                        .foregroundColor(Color("lawenda2"))
                                    Spacer()
                                        let minutes = countDownTimer12/60
                                        let seconds = countDownTimer12 % 60
                                        
                                        Text("\(minutes):\(seconds)")
                                            .onReceive(timer12){ _ in
                                                if countDownTimer12 > 0 && timerRuning12 {
                                                    countDownTimer12 -= 1
                                                } else{
                                                    timerRuning12 = false
                                                }
                                            }
                                            .font(.title)
                                            .foregroundColor(Color.white)
                                            Spacer()
                                        HStack(spacing: 30){
                                            
                                            Button {
                                                timerRuning12 = true
                                            } label: {
                                                Image(systemName: "play.circle.fill")
                                                    .font(.largeTitle)
                                                    .foregroundColor(Color.white)
                                            }
                                            
                                            Button {
                                                timerRuning12 = false
                                            } label: {
                                                Image(systemName: "pause.circle.fill")
                                                    .font(.largeTitle)
                                                    .foregroundColor(Color.white)
                                            }
                                            
                                            Button {
                                                countDownTimer12 = 30
                                            } label: {
                                                Image(systemName: "gobackward")
                                                    .font(.title)
                                                    .foregroundColor(Color.white)
                                            }
                                        }
                                    Spacer()
                                    Spacer()
                                    Spacer()
                                        
                                    }
                                
                            )
                        
                    RoundedRectangle(cornerRadius: 25)
                        .frame(width: 350, height: 520)
                        .foregroundColor(Color("lawenda"))
                        .padding()
                        .overlay(
                            VStack{
                            Text("Deska")
                                    .font(.title2)
                                    .foregroundColor(Color.white)
                                    .frame(width: 150, height: 70)
                                    .background(Color("pomarancz"))
                                    .cornerRadius(25)
                                VStack{
                                    let minutes = countDownTimer6/60
                                    let seconds = countDownTimer6 % 60
                                    
                                    Text("\(minutes):\(seconds)")
                                  //  Text("\(countDownTimer6)")
                                        .onReceive(timer6){ _ in
                                            if countDownTimer6 > 0 && timerRuning6 {
                                                countDownTimer6 -= 1
                                            } else{
                                                timerRuning6 = false
                                            }
                                        }
                                        .font(.title)
                                        .foregroundColor(Color("pomarancz"))
                                        
                                    HStack(spacing: 30){
                                        
                                        Button {
                                            timerRuning6 = true
                                        } label: {
                                            Image(systemName: "play.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                        
                                        Button {
                                            timerRuning6 = false
                                        } label: {
                                            Image(systemName: "pause.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                        
                                        Button {
                                            countDownTimer6 = 90
                                        } label: {
                                            Image(systemName: "gobackward")
                                                .font(.title)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                    }
                                    
                                    
                                }

                                deskaImage("deska")
                                    .frame(width: 300, height: 300)
                                    .cornerRadius(25)
                                    .padding()
                                
                                Image(systemName: "arrow.right")
                                        .foregroundColor(Color("lawenda2"))
                            }
                            
                        )
                        
                        RoundedRectangle(cornerRadius: 25)
                            .frame(width: 250, height: 200)
                            .foregroundColor(Color("lawenda"))
                            .padding()
                            .overlay(
                                VStack{
                                    Spacer()
                                    Spacer()
                                    Text("Chwila odpoczynku")
                                        .font(.title2)
                                        .bold()
                                        .foregroundColor(Color("lawenda2"))
                                    Spacer()
                                        let minutes = countDownTimer13/60
                                        let seconds = countDownTimer13 % 60
                                        
                                        Text("\(minutes):\(seconds)")
                                            .onReceive(timer13){ _ in
                                                if countDownTimer13 > 0 && timerRuning13 {
                                                    countDownTimer13 -= 1
                                                } else{
                                                    timerRuning13 = false
                                                }
                                            }
                                            .font(.title)
                                            .foregroundColor(Color.white)
                                            Spacer()
                                        HStack(spacing: 30){
                                            
                                            Button {
                                                timerRuning13 = true
                                            } label: {
                                                Image(systemName: "play.circle.fill")
                                                    .font(.largeTitle)
                                                    .foregroundColor(Color.white)
                                            }
                                            
                                            Button {
                                                timerRuning13 = false
                                            } label: {
                                                Image(systemName: "pause.circle.fill")
                                                    .font(.largeTitle)
                                                    .foregroundColor(Color.white)
                                            }
                                            
                                            Button {
                                                countDownTimer13 = 30
                                            } label: {
                                                Image(systemName: "gobackward")
                                                    .font(.title)
                                                    .foregroundColor(Color.white)
                                            }
                                        }
                                    Spacer()
                                    Spacer()
                                    Spacer()
                                        
                                    }
                                
                            )
                    
                    RoundedRectangle(cornerRadius: 25)
                        .frame(width: 350, height: 520)
                        .foregroundColor(Color("lawenda"))
                        .padding()
                        .overlay(
                            VStack{
                            Text("Flutter kicks")
                                    .font(.title2)
                                    .foregroundColor(Color.white)
                                    .frame(width: 150, height: 70)
                                    .background(Color("pomarancz"))
                                    .cornerRadius(25)
                                VStack{
                                    let minutes = countDownTimer7/60
                                    let seconds = countDownTimer7 % 60
                                    
                                    Text("\(minutes):\(seconds)")
                                  //  Text("\(countDownTimer5)")
                                        .onReceive(timer7){ _ in
                                            if countDownTimer7 > 0 && timerRuning7 {
                                                countDownTimer7 -= 1
                                            } else{
                                                timerRuning7 = false
                                            }
                                        }
                                        .font(.title)
                                        .foregroundColor(Color("pomarancz"))
                                        
                                    HStack(spacing: 30){
                                        
                                        Button {
                                            timerRuning7 = true
                                        } label: {
                                            Image(systemName: "play.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                        
                                        Button {
                                            timerRuning7 = false
                                        } label: {
                                            Image(systemName: "pause.circle.fill")
                                                .font(.largeTitle)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                        
                                        Button {
                                            countDownTimer7 = 120
                                        } label: {
                                            Image(systemName: "gobackward")
                                                .font(.title)
                                                .foregroundColor(Color("pomarancz"))
                                        }
                                    }
                                    
                                    
                                }

                                flutterkicksImage("flutterkicks")
                                    .frame(width: 300, height: 300)
                                    .cornerRadius(25)
                                    .padding()
                                
                                Image(systemName: "arrow.right")
                                        .foregroundColor(Color("lawenda2"))
                            }
                            
                        )
                   

                    RoundedRectangle(cornerRadius: 25)
                        .frame(width: 350, height: 520)
                        .foregroundColor(Color("lawenda"))
                        .padding()
                        .overlay(
                            VStack{
                                Spacer()
                                Text("Gratulacje")
                                    .font(.title)
                                    .foregroundColor(Color.white)
                                    .padding()
                                    .background(Color("pomarancz"))
                                    .cornerRadius(25)
                                Spacer()
                        superImage("super")
                            .frame(width: 300, height: 300)
                            .cornerRadius(25)
                                Spacer()
                            }
                        )
                    }
                }
            }
            }
            }
        }
    }
}

struct Cardio_Previews: PreviewProvider {
    static var previews: some View {
        Cardio()
    }
}

