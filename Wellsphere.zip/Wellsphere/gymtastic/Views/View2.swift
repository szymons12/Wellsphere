//
//  View2.swift
//  gymtastic
//
//  Created by szymon on 04/12/2021.
//

import SwiftUI

struct View2: View {
    @ObservedObject var timerManager = TimerManager()
    @State var selectedPickerIndex = 0
    let availableMinutes = Array(1...15)
     
    var body: some View {
        NavigationView{
            ZStack{
                Color("backgroundColor").ignoresSafeArea()
               // Image("zestaw6")
                //    .resizable()
                 //   .frame(width: 500, height: 600)
            VStack{
                Text(secondsToMinutesAndSeconds(seconds: timerManager.secondsLeft))
                    .foregroundColor(Color("kafelek"))
                    .font(.largeTitle)
                    .padding(.top, 80)
                // to odnosi sie do licznika
                
                Image(systemName: timerManager.timerMode == .running ? "pause.circle.fill" : "play.circle.fill")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 180, height: 180)
                    .foregroundColor(Color("kafelek"))
                    // guziczek
                // to odnosi sie do przyciskow
                    .onTapGesture(perform: {
                        if self.timerManager.timerMode == .initial{
                            self.timerManager.setTimerLength(minutes: self.availableMinutes[self.selectedPickerIndex]*60)
                        }
                        self.timerManager.timerMode == .running ? self.timerManager.pause() : self.timerManager.start()
                    })
                // koniec guziczka
                // poczatek if
                if timerManager.timerMode == .paused{
                    Image(systemName: "gobackward")
                        .foregroundColor(Color("kafelek"))
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 50, height: 50)
                        .padding(.top, 40)
                        .onTapGesture(perform: {
                            self.timerManager.reset()
                            // to odnosi sie do tego zmienneg przycisku
                        })
                } // koniec if
                
                if timerManager.timerMode == .initial{
                    Picker(selection: $selectedPickerIndex,
                           label: Text("")){
                        ForEach(0 ..< availableMinutes.count){
                            Text("\(self.availableMinutes[$0])min")
                    // odnosi sie do 1min ale nie potrafie zmienic kolorku :(
                        }
                    }
                    .labelsHidden()
                }
                Spacer()
            }
        }
        }
    }
}

struct View2_Previews: PreviewProvider {
    static var previews: some View {
        View2()
            
    }
}
