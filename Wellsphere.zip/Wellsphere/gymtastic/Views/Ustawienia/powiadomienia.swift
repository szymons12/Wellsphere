//
//  ocenaView.swift
//  Wellsphere
//
//  Created by szymon on 04/03/2022.
//

import SwiftUI
import StoreKit
struct powiadomienia: View {
    @Environment(\.openURL) var openURL
    var body: some View {
        ZStack{
            Color("lawenda").ignoresSafeArea()
            VStack{
                Spacer()
                Text("Dzięki włączonym powiadomieniom aplikacja będzie mogła powiadomić cię o nadchodzącym treningu. Jeśli nie otrzymujesz powiadomień, kliknij poniższy przycisk.")
                    .foregroundColor(Color.white)
                    .font(.title3)
                    .padding()
                    .background(Color("lawenda2"))
                    .cornerRadius(25)
                    .padding()
                
        Button(action: openSettings) {
                   Text("Włącz lub wyłącz powiadomienia")
                .font(.title)
                .foregroundColor(Color.white)
                .padding()
                .background(Color("pomarancz"))
                .cornerRadius(25)
               }
                Spacer()
                Spacer()
               

        }
        }
           }

            func openSettings() {
               openURL(URL(string: UIApplication.openSettingsURLString)!)
           }
       }

struct powiadomienia_Previews: PreviewProvider {
    static var previews: some View {
        powiadomienia()
    }
}

