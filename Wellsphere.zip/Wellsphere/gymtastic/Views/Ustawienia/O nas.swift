//
//  O nas.swift
//  Wellsphere
//
//  Created by szymon on 21/02/2022.
//

import SwiftUI

struct O_nas: View {
    var body: some View {
        ZStack{
            Color("lawenda").ignoresSafeArea()
            VStack{
                Spacer()
                Text("Co to Wellsphere ?")
                    .font(.title)
                    .foregroundColor(Color.white)
                    .padding()
                    .background(Color("lawenda2"))
                    .cornerRadius(25)
                Spacer()
                Text("Jesteśmy uczniami szkół średnich, którzy postanowili wspólnie stworzyć projekt Wellsphere.Projekt Wellsphere ma na celu promowanie zdrowego trybu życia wśród młodzieży. Na naszej stronie internetowej oraz w aplikacji, każdy zainteresowany będzie miał darmowy dostęp do materiałów na temat aktywności fizycznej, zdrowa psychicznego, prawidłowej diety i sposobów na poprawienie samopoczucia.")
                    .font(.title3)
                    .foregroundColor(Color.white)
                    .padding()
                    .background(Color("lawenda2"))
                    .cornerRadius(25)
                Spacer()
                Spacer()
                Spacer()
                Spacer()
            }
    }
    }
}

struct O_nas_Previews: PreviewProvider {
    static var previews: some View {
        O_nas()
    }
}
