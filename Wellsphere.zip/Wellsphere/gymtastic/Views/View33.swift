//
//  View33.swift
//  gymtastic
//
//  Created by szymon on 20/12/2021.
//

import SwiftUI

struct View33: View {
    
    @State var showSheet: Bool = false
    var body: some View {
        
        
        NavigationView{
        ZStack{
            Color("lawenda").ignoresSafeArea()
            VStack{
                ScrollView{
//----------------------------Tytul----------------------------------------
                
                
                    Text("Treningi")
                        .bold()
                        .foregroundColor(Color.white)
                    .font(.largeTitle)
                    .padding()
                    Spacer()
                    HStack{
                    Text("Ćwiczenia podstawowe")
                    .foregroundColor(Color("pomarancz"))
                    .font(.title)
                    .padding()
                        
                        Button(action: {
                            showSheet.toggle()
                        }, label: {
                            Image(systemName: "questionmark.circle")
                                .font(.title)
                                .foregroundColor(Color.white)
                        })
                            .fullScreenCover(isPresented: $showSheet, content: {
                                wiczeniaPView()                            })
                    }
//------------------------------naglowek1----------------------------------
                ScrollView(.horizontal){
                HStack{
                    
                    ScrollView(.horizontal){
                    HStack{
                        NavigationLink(
                            destination: bodyworkout(),
                            label: {
                                Image("new12")
                                    .resizable()
                                    .frame(width: 300, height: 250)
                                    .background(Color("lawenda2"))
                                    .clipped()
                                    .cornerRadius(25)
                                    .overlay(
                                        Text("Full body workout")
                                            .foregroundColor(Color.white)
                                            .frame(width: 200, height: 50)
                                            .background(Color("pomarancz").opacity(0.9))
                                            .cornerRadius(25))
                            })
                        .padding()
                    
                        NavigationLink(
                            destination: pilates(),
                            label: {
                                Image("new6")
                                    .resizable()
                                    .frame(width: 300, height: 250)
                                    .background(Color("lawenda2"))
                                    .clipped()
                                    .cornerRadius(25)
                                    .overlay(
                                        Text("Pilates")
                                            .foregroundColor(Color.white)
                                            .frame(width: 200, height: 50)
                                            .background(Color("pomarancz").opacity(0.9))
                                            .cornerRadius(25))
                            })
                        NavigationLink(
                            destination: artykul1(),
                            label: {
                                Image("new9")
                                    .resizable()
                                    .frame(width: 300, height: 250)
                                    .background(Color("lawenda2"))
                                    .clipped()
                                    .cornerRadius(25)
                                    .overlay(
                                        Text("Rozgrzewka przed morsowaniem")
                                            .foregroundColor(Color.white)
                                            .frame(width: 200, height: 50)
                                            .background(Color("pomarancz").opacity(0.9))
                                            .cornerRadius(25))
                            })
                            .padding()
                    }
                    
                    }
                        
                }
                
                }
//----------------------------------koniec pierwszego naglowka-------------
                    HStack{
                Text("Ćwiczenia zaawansowane")
                .foregroundColor(Color("pomarancz"))
                .font(.title)
                    
                        
                      Button(action: {
                          showSheet.toggle()
                     }, label: {
                          Image(systemName: "questionmark.circle")                               .font(.title)                              .foregroundColor(Color.white)
                      })
                          .fullScreenCover(isPresented: $showSheet, content: {
                              cwiczeniazView()
                          })
                    }
                    ScrollView(.horizontal){
                    HStack{
                        NavigationLink(
                            destination: Cardio(),
                            label: {
                                Image("new5")
                                    .resizable()
                                    .frame(width: 300, height: 250)
                                    .background(Color("lawenda2"))
                                    .clipped()
                                    .cornerRadius(25)
                                    .overlay(
                                        Text("Trening Cardio")
                                            .foregroundColor(Color.white)
                                            .frame(width: 200, height: 50)
                                            .background(Color("pomarancz").opacity(0.9))
                                            .cornerRadius(25))
                            })
               
                        .padding()
                        
                        NavigationLink(
                            destination: americanPsycho(),
                            label: {
                                Image("new3")
                                    .resizable()
                                    .frame(width: 300, height: 250)
                                    .background(Color("lawenda2"))
                                    .clipped()
                                    .cornerRadius(25)
                                    .overlay(
                                        Text("American psycho")
                                            .foregroundColor(Color.white)
                                            .frame(width: 200, height: 50)
                                            .background(Color("pomarancz").opacity(0.9))
                                            .cornerRadius(25))
                            })
                            
                    }
                    
                    }
            }
            }
        .navigationBarHidden(true)
        .accentColor(Color("pomarancz"))
        }
    }
}
}
struct View33_Previews: PreviewProvider {
    static var previews: some View {
        View33()
    }
}

